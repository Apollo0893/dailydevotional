# Daily Audio Devotional Generator (with Web UI)

Includes:
- Daily MP3 devotional generation
- Ollama local LLM reflections
- Weekly topic control via env vars
- **Web UI for preview + manual regenerate**

Web UI available at: http://localhost:8080
